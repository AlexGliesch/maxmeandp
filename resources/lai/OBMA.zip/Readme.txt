To run the OBMA algorithm, four parameters are: Instance Name, Dataset Name, Time Limit, Number of Runs.

For example, to solve the instance MDG-a_21_n2000_m200.txt of dataset MDG-a 30 times with the time limit of t = 3600 seconds per run, do the following

./OBMA.exe MDG-a_21_n2000_m200.txt MDG-a 3600 30
